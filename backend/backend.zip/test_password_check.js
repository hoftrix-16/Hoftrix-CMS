const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/hoftrix_db';

mongoose.connect(mongoURI).then(async () => {
  console.log('Connected to MongoDB. Fetching Ashu Sharma password hash...');
  
  const User = mongoose.model('User', new mongoose.Schema({
    email: String,
    password: String
  }, { collection: 'users' }));
  
  const user = await User.findOne({ email: 'ashu@gmail.com' });
  if (!user) {
    console.log('❌ User ashu@gmail.com not found!');
  } else {
    console.log('✅ User found. Hashed password in DB:', user.password);
    
    const candidatePasswords = ['welcome123@', 'welcome@123'];
    for (const pw of candidatePasswords) {
      const isMatch = await bcrypt.compare(pw, user.password);
      console.log(`- Comparison with "${pw}": ${isMatch ? '✅ MATCH!' : '❌ NO MATCH'}`);
    }
  }
  
  mongoose.disconnect();
}).catch(err => console.error(err));
