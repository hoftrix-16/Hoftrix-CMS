const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/hoftrix_db';

const User = require('./models/User');

mongoose.connect(mongoURI).then(async () => {
  console.log('Connected to MongoDB. Simulating Reset Password Flow...');
  
  let user = await User.findOne({ email: 'ashu@gmail.com' });
  if (!user) {
    console.log('❌ User ashu@gmail.com not found!');
  } else {
    console.log('✅ Current password hash in DB before simulation:', user.password);
    
    // Simulate reset
    const defaultPassword = 'welcome123@';
    user.password = defaultPassword;
    console.log('Setting user.password to:', defaultPassword);
    console.log('Is password modified?', user.isModified('password'));
    
    await user.save();
    console.log('Saved user document!');
    
    // Read back
    const updatedUser = await User.findOne({ email: 'ashu@gmail.com' });
    console.log('✅ Updated password hash in DB after simulation:', updatedUser.password);
    
    const isMatch = await bcrypt.compare('welcome123@', updatedUser.password);
    console.log(`- Comparison with "welcome123@": ${isMatch ? '✅ MATCH!' : '❌ NO MATCH'}`);
  }
  
  mongoose.disconnect();
}).catch(err => console.error(err));
