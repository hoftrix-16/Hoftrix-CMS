const mongoose = require('mongoose');
const mongoURI = 'mongodb://127.0.0.1:27017/hoftrix_db';

mongoose.connect(mongoURI).then(async () => {
  const collections = await mongoose.connection.db.listCollections().toArray();
  console.log('Collections list:', collections.map(c => c.name));
  
  const rawProjects = await mongoose.connection.db.collection('projects').find().toArray();
  console.log('Projects raw array count:', rawProjects.length);
  console.log('Projects array contents:', rawProjects);
  
  mongoose.disconnect();
}).catch(err => console.error(err));
