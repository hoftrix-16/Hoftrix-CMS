const mongoose = require('mongoose');
require('dotenv').config();

const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/hoftrix_db';

mongoose.connect(mongoURI).then(async () => {
  console.log('Connected to MongoDB. Fetching users list...');
  const users = await mongoose.connection.db.collection('users').find().toArray();
  console.log('--- USERS REGISTERED ---');
  users.forEach(u => {
    console.log(`- Name: ${u.name}, Email: "${u.email}", Role: ${u.role}, ID: ${u._id}`);
  });
  console.log('------------------------');
  
  const employees = await mongoose.connection.db.collection('employees').find().toArray();
  console.log('--- EMPLOYEES REGISTERED ---');
  employees.forEach(e => {
    console.log(`- Name: ${e.name}, Email: "${e.email}", ID: ${e._id}`);
  });
  console.log('----------------------------');
  
  mongoose.disconnect();
}).catch(err => console.error(err));
